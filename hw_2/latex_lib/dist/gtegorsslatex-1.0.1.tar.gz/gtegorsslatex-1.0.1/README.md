# Latex Lib
Package for MHS Python Homework 2
LaTeX

@GTEgorss